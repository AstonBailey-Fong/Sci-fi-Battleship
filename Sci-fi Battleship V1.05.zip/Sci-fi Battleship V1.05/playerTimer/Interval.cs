﻿namespace playerTimer
{
    internal class Interval
    {
    }
}