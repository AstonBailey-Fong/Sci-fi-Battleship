﻿namespace Sci_fi_Battleship
{
    internal class Form2
    {
    }
}